 <!-- Icon css link -->
 <link href="{{ asset('web_asset/css/font-awesome.min.css') }}" rel="stylesheet">
 <!-- Bootstrap -->
 <link href="{{ asset('web_asset/css/bootstrap.min.css') }}" rel="stylesheet">
 {{-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"> --}}

 <!-- Rev slider css -->
 <link href="{{ asset('web_asset/vendors/revolution/css/settings.css') }}" rel="stylesheet">
 <link href="{{ asset('web_asset/vendors/revolution/css/layers.css') }}" rel="stylesheet">
 <link href="{{ asset('web_asset/vendors/revolution/css/navigation.css') }}" rel="stylesheet">

 <!-- Extra plugin css -->
 <link href="{{ asset('web_asset/vendors/owl-carousel/owl.carousel.min.css') }}" rel="stylesheet">

 <link href="{{ asset('web_asset/css/style.css') }}" rel="stylesheet">
 <link href="{{ asset('web_asset/css/responsive.css') }}" rel="stylesheet">
 <link href="{{ asset('web_asset/css/custom-colors.css') }}" rel="stylesheet">
 <link rel="stylesheet" href="{{ asset('web_asset/fonts/commuterssans-bold.otf') }}">
<link rel="stylesheet" href="{{ asset('web_asset/css/responsiveness.css') }}">
 <link rel="stylesheet" href="{{ asset('web_asset/css/custom-animation.css') }}">

 {{-- <!—Google tag (gtag.js)  --}}
<script async src=https://www.googletagmanager.com/gtag/js?id=G-B77ZFZ5GK6></script>
